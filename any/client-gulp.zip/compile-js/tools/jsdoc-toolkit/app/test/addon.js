String.prototype.reverse = function() {
}

String.prototype.reverse.utf8 = function() {
}

Function.count = function() {
}

/** @memberOf Function */
Function.count.reset = function() {
}

/** @memberOf Function */
count.getValue = function() {
}

/** @memberOf Function.prototype */
getSig = function() {
}

/** @memberOf Function.prototype */
Function.prototype.getProps = function() {
}
