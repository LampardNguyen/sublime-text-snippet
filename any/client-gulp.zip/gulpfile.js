/*!
 * gulp
 * $ npm install gulp-ruby-sass gulp-autoprefixer gulp-minify-css gulp-jshint gulp-concat gulp-uglify gulp-imagemin gulp-notify gulp-rename gulp-livereload gulp-cache del --save-dev
 */
'use strict';

var gulp = require('gulp'),
    sass = require('gulp-ruby-sass'),
    autoprefixer = require('gulp-autoprefixer'),
    minifycss = require('gulp-minify-css'),
    jshint = require('gulp-jshint'),
    uglify = require('gulp-uglify'),
    //imagemin = require('gulp-imagemin'),
    rename = require('gulp-rename'),
    concat = require('gulp-concat'),
    notify = require('gulp-notify'),
    cache = require('gulp-cache'),
    livereload = require('gulp-livereload'),
    del = require('del');

var PATHS = {
    // Destination folder
    DEST_DIR : '../../src/main/webapp/resources',
    DEST_DIR_JS : '../../src/main/webapp/resources/js',
    DEST_DIR_CSS : '../../src/main/webapp/resources/css',
    DEST_DIR_IMG : '../../src/main/webapp/resources/img',
    DEST_DIR_FONTS : '../../src/main/webapp/resources/fonts',

    // VENDOR
    VENDOR : 'vendor',
    DIR_JS: './src/js',
    DIR_SCSS: './src/scss',
    DIR_IMAGES: './src/images',
    DIR_DIST: './dist',
    MANUAL_VENDOR: 'manual-vendor'
};

/**
 * Build vendor js + css
 * Usage: gulp vendor
 */
gulp.task('vendor', function() {
    // Vendor JS
    gulp.src([
            PATHS.VENDOR + '/jquery/dist/jquery.min.js',
            PATHS.VENDOR + '/bootstrap/dist/js/bootstrap.min.js',
            PATHS.VENDOR + '/interact/interact.min.js',
        ])
        .pipe(concat('vendors.js'))
        .pipe(gulp.dest(PATHS.DEST_DIR_JS))
        .pipe(notify({ message: 'Create vendors.js complete' }));

    // Vendor CSS
    gulp.src([
            //PATHS.VENDOR + '/bootstrap/dist/css/bootstrap.min.css',
            PATHS.MANUAL_VENDOR + '/bootstrap.css',
            PATHS.VENDOR + '/font-awesome/css/font-awesome.min.css'
        ])
        .pipe(concat('vendors.css'))
        .pipe(gulp.dest(PATHS.DEST_DIR_CSS))
        .pipe(notify({ message: 'Create vendors.css complete' }));

    // Copy fonts
    gulp.src([
            PATHS.VENDOR + '/bootstrap/fonts/*.*',
            PATHS.VENDOR + '/font-awesome/fonts/*.*'
        ])
        .pipe(gulp.dest(PATHS.DEST_DIR_FONTS));

    // Copy image

     // Copy Other
        gulp.src([
                PATHS.VENDOR + '/chosen/*.png'
            ])
            .pipe(gulp.dest(PATHS.DEST_DIR_CSS));
    });

/**
 * SCSS
 * Usage: gulp styles
 */
gulp.task('styles', function() {
    // style: compact, compressed, or expanded.
    return sass( PATHS.DIR_SCSS + '/app.scss',
            { style: 'expanded', compass: true , lineNumbers: true}
        )
        .on('error', function (err) {
            console.error('Error!', err.message);
        })
        //.pipe(autoprefixer('last 2 version'))
        .pipe(gulp.dest(PATHS.DEST_DIR_CSS))
        .pipe(rename({ suffix: '.min' }))
        .pipe(minifycss())
        .pipe(gulp.dest(PATHS.DEST_DIR_CSS))
        .pipe(notify({ message: 'Styles task complete' }));
});

/**
 * Scripts
 * Usage: gulp scripts
 */
gulp.task('scripts', function() {
    var sources = [
        // ** MODULES JS
        PATHS.DIR_JS + '/utils/*.js',
        PATHS.DIR_JS + '/pages/*.js'
        //PATHS.DIR_JS + '/app.js'
    ];

    return gulp.src( sources )
        .pipe(jshint('.jshintrc'))
        .pipe(jshint.reporter('jshint-stylish'))
        .pipe(concat('app.js'))
        .pipe(gulp.dest(PATHS.DEST_DIR_JS))
        .pipe(rename({ suffix: '.min' }))
        //.pipe(uglify())
        //.pipe(gulp.dest(PATHS.DEST_DIR_JS))
        .pipe(notify({ message: 'Scripts task complete' }));
});

/**
 * images
 * Usage: gulp images
 */
// gulp.task('images', function() {
//   return gulp.src( PATHS.DIR_IMAGES + '/**/*')
//     .pipe(cache(imagemin({ optimizationLevel: 3, progressive: true, interlaced: true })))
//     .pipe(gulp.dest('dist/images'))
//     .pipe(notify({ message: 'Images task complete' }));
// });

// Clean
gulp.task('clean', function(cb) {
    del(['dist/assets/css', 'dist/assets/js', 'dist/assets/img'], cb)
});

// Default task
gulp.task('default', ['clean'], function() {
    gulp.start('styles', 'scripts');
});

// Watch
gulp.task('watch', function() {

  // Watch .scss files
  //gulp.watch( PATHS.DIR_SCSS + '/**/*.scss', ['styles']);

  // Watch .js files
  gulp.watch( PATHS.DIR_JS + '/**/*.js', ['scripts']);

  // Watch image files
  //gulp.watch( PATHS.DIR_IMAGES + '/**/*', ['images']);

  // Create LiveReload server
  //livereload.listen();

  // Watch any files in dist/, reload on change
  //gulp.watch(['dist/**']).on('change', livereload.changed);

});