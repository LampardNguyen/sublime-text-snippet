/**
 * Utils
 * @author Nguyen Phu Cuong
 */
var Utils = {

    _isSafari: false,
    _isChrome: false,
    _isFirefox: false,

    isSafari: function() {

        if( this._isSafari ) {
            return true;
        }

        var ua = navigator.userAgent.toLowerCase();
        if (ua.indexOf('safari') != -1) {
            if (ua.indexOf('chrome') > -1) {
              return false;
            } else {
              this._isSafari = true;
              return true;
            }
          }
        return false;
    },

    isChrome: function() {

        if( this._isChrome ) {
            return true;
        }

        var ua = navigator.userAgent.toLowerCase();
        if (ua.indexOf('safari') != -1) {
            if (ua.indexOf('chrome') > -1) {
              this._isChrome = true;
              return true;
            } else {
              return false;
            }
          }
        return _isChrome;
    },

    isFirefox: function() {

        if( this._isFirefox ) {
            return true;
        }

        var ua = navigator.userAgent.toLowerCase();
        if (ua.indexOf('firefox') != -1) {
            this._isFirefox = true;
        }
        return this._isFirefox;
    }

};