X1012 = function() {

};

X1012.prototype.init = function() {
    setInterval(function(){
        window.location.href = getContextPath() +  $("#formAction").val();
    },2500);
}