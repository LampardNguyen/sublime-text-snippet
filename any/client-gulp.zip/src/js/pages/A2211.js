/**
 * Copyright(c) MEDIA DO Co., Ltd All rights reserved.
 */
A2211 = function() {

};

A2211.prototype.init = function() {

    function setHeaderAjax() {

        $.ajaxSetup({
            headers : {
                'X-CSRF-TOKEN' : $('meta[name=_csrf]').attr('content')
            }
        });
    }
    $('#fontFile').on('change', function() {

        $('#fontFileName').val($(this).val());
    });
    $('#fontNameDelete').click(function(){
        $(this).parent().remove();
        $("input[name='blnFontAttached']").val(false);
        $("#fontFileName").val('');
    });
    $('#fontNameBoldDelete').click(function(){
        $(this).parent().remove();
        $("input[name='blnBoldAttached']").val(false);
        $("#fontFileNameBold").val('');
    });
    $('#fontNameItalicDelete').click(function(){
        $(this).parent().remove();
        $("input[name='blnItalicAttached']").val(false);
        $("#fontFileNameItalic").val('');
    });
    $('#fontNameBoldItalicDelete').click(function(){
        $(this).parent().remove();
        $("input[name='blnBoldItalicAttached']").val(false);
        $("#fontFileNameBoldItalic").val('');
    });
}
