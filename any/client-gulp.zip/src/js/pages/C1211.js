/**
 * Copyright(c) MEDIA DO Co., Ltd All rights reserved.
 */
C1211 = function() {

};

C1211.prototype.init = function() {

    $(function() {

        $("#datepicker").datepicker({
            dateFormat : 'yy-mm-dd'
        });
    });

    function setHeaderAjax() {

        $.ajaxSetup({
            headers : {
                'X-CSRF-TOKEN' : $('meta[name=_csrf]').attr('content')
            }
        });
    }
    $('#intTitleId').on('change', function() {

        setHeaderAjax();
        var params = {
            'intTitleId' : eval(this.value)
        };
        $.ajax({
            method : 'POST',
            url : getContextPath() + '/admin/Workorder/GetListContent',
            data : JSON.stringify(params),
            contentType : 'application/json',
            beforeSend : function(xhrObj) {

                xhrObj.setRequestHeader("Content-Type", "application/json");
                xhrObj.setRequestHeader("Accept", "application/json");
            },
            success : function(data) {

                $("#intContentId").find('option').remove();
                $("#intLpairId").find('option').remove();
                $.each(data, function(i, value) {

                    // $('#intContentId').append( $('<option>').text('').attr('value', '0'));
                    $('#intContentId').append($('<option>').text(value.display).attr('value', value.value));
                });
                $("#intContentId").trigger('change');
                //$("#intLpairId").trigger('change');
            }
        });
    });

    $('#intContentId').on('change', function() {

        setHeaderAjax();
        var params = {
            'intContentId' : eval(this.value)
        };
        if (params.intContentId < 1) {
            $("#intLpairId").find('option').remove();

        } else {
            $.ajax({
                method : 'POST',
                url : getContextPath() + '/admin/Workorder/GetListLpair',
                data : JSON.stringify(params),
                contentType : 'application/json',
                beforeSend : function(xhrObj) {

                    xhrObj.setRequestHeader("Content-Type", "application/json");
                    xhrObj.setRequestHeader("Accept", "application/json");
                },
                success : function(data) {

                    $("#intLpairId").find('option').remove();
                    $.each(data, function(i, value) {

                        $('#intLpairId').append($('<option>').text(value.display).attr('value', value.value));

                    });
                }
            });
        }

    });

    $(".changeStatus").click(function(){
        var action = $(this).attr('action');
        var intStatus = $(this).attr('value');
        var mess = $('#confirmChangeStatus').val();
        mess = mess.replace('{0}', $('#' + $(this).attr("value")).val());
        bootbox.dialog({
            message: mess,
            buttons:{
                success:{
                    label:$('#COM_LABEL_CANCEL').val(),
                    className:"btn-danger",
                    callback:function() {
                    }
                },
                danger:{
                    label:$('#COM_LABEL_OK').val(),
                    className:"btn-primary",
                    callback:function() {
                        $('#intStatus').val(intStatus);
                        $('form').attr('action', action);
                        $('form').submit();
                    }
                }
            }
        });
    });
}
