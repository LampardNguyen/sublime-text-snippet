/**
 * Copyright(c) MEDIA DO Co., Ltd All rights reserved.
 */
A2011 = function() {

};

A2011.prototype.init = function() {

    function setHeaderAjax() {

        $.ajaxSetup({
            headers : {
                'X-CSRF-TOKEN' : $('meta[name=_csrf]').attr('content')
            }
        });
    }
    $('#chrLangCod').on('change', function() {
        if($(this).val().trim() == null || $(this).val().trim().length == 0) {
            $('#affFile').attr("disabled", true);
            $('#dicFile').attr("disabled", true);
            $('#blnAffAttached').val(false);
            $('#blnDicAttached').val(false);
        }else{
            $('#affFile').attr("disabled", false);
            $('#dicFile').attr("disabled", false);
        }
    });
    $('#affFile').on('change', function() {

        $('#affFileName').val($(this).val());
    });

    $('#dicFile').on('change', function() {

        $('#dicFileName').val($(this).val());
    });

}
